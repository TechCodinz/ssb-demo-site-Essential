"""Messages package"""
from .templates import *
